# medical-site-
A single page website for a medical facility 
## Technologies
* HTML
* CSS
